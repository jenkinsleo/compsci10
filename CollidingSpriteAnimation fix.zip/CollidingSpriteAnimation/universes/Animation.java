
public interface Animation {
	
	public Universe getNextUniverse();	

}
